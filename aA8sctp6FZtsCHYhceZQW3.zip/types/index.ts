export type PlanType = 'free' | 'premium' | 'pro';

export interface User {
  id: string;
  name: string;
  email: string;
  plan: PlanType;
}

export interface Resource {
  id: string;
  title: string;
  description: string;
  category: ResourceCategory;
  isPremium: boolean;
  content: string;
  duration?: string;
  difficulty?: 'easy' | 'medium' | 'hard';
  tags: string[];
  imageUrl?: string;
}

export type ResourceCategory = 
  | 'diet'
  | 'therapy'
  | 'motor'
  | 'communication'
  | 'sensory'
  | 'behavior';

export interface Plan {
  type: PlanType;
  name: string;
  price: string;
  features: string[];
  popular?: boolean;
}
