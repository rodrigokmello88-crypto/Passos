import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, spacing, borderRadius, typography } from '@/constants/theme';
import { commonStyles } from '@/constants/styles';
import { ResourceCard, UpgradeModal } from '@/components';
import { useUser } from '@/hooks/useUser';
import { useResources } from '@/hooks/useResources';
import { ResourceCategory } from '@/types';
import { useRouter } from 'expo-router';

export default function LibraryScreen() {
  const insets = useSafeAreaInsets();
  const { user } = useUser();
  const { resources, selectedCategory, setSelectedCategory, canAccess } = useResources(user.plan);
  const router = useRouter();
  const [upgradeModalVisible, setUpgradeModalVisible] = useState(false);

  const categories: Array<{
    value: ResourceCategory | 'all';
    label: string;
  }> = [
    { value: 'all', label: 'Todos' },
    { value: 'diet', label: 'Alimentação' },
    { value: 'therapy', label: 'Terapias' },
    { value: 'motor', label: 'Motora' },
    { value: 'communication', label: 'Comunicação' },
    { value: 'sensory', label: 'Sensorial' },
    { value: 'behavior', label: 'Comportamento' },
  ];

  const handleResourcePress = (resourceId: string) => {
    const resource = resources.find(r => r.id === resourceId);
    if (resource && !canAccess(resource)) {
      setUpgradeModalVisible(true);
    } else {
      // Navigate to resource detail (will implement later)
      console.log('Open resource:', resourceId);
    }
  };

  return (
    <View style={[commonStyles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Biblioteca</Text>
        <Text style={styles.subtitle}>
          {resources.length} {resources.length === 1 ? 'recurso' : 'recursos'}
        </Text>
      </View>

      {/* Category Filter */}
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.categoryScroll}
      >
        {categories.map((cat) => (
          <TouchableOpacity
            key={cat.value}
            style={[
              styles.categoryChip,
              selectedCategory === cat.value && styles.categoryChipActive,
            ]}
            onPress={() => setSelectedCategory(cat.value)}
            activeOpacity={0.7}
          >
            <Text style={[
              styles.categoryChipText,
              selectedCategory === cat.value && styles.categoryChipTextActive,
            ]}>
              {cat.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Resources List */}
      <ScrollView 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
      >
        {resources.map((resource) => (
          <ResourceCard
            key={resource.id}
            resource={resource}
            canAccess={canAccess(resource)}
            onPress={() => handleResourcePress(resource.id)}
          />
        ))}
        
        {resources.length === 0 && (
          <View style={styles.emptyState}>
            <Text style={styles.emptyText}>Nenhum recurso encontrado</Text>
          </View>
        )}
      </ScrollView>

      <UpgradeModal
        visible={upgradeModalVisible}
        onClose={() => setUpgradeModalVisible(false)}
        onUpgrade={() => {
          setUpgradeModalVisible(false);
          router.push('/plans');
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    paddingBottom: spacing.md,
  },
  title: {
    ...typography.h1,
    fontSize: 32,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  subtitle: {
    ...typography.body,
    color: colors.textSecondary,
  },
  categoryScroll: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
    gap: spacing.sm,
  },
  categoryChip: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.full,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
  },
  categoryChipActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  categoryChipText: {
    ...typography.bodySmall,
    fontWeight: '600',
    color: colors.text,
  },
  categoryChipTextActive: {
    color: colors.surface,
  },
  content: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.xxl,
  },
  emptyState: {
    paddingVertical: spacing.xxl,
    alignItems: 'center',
  },
  emptyText: {
    ...typography.body,
    color: colors.textSecondary,
  },
});
