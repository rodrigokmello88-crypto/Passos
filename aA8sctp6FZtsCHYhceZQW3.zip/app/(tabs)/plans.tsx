import React from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, spacing, typography } from '@/constants/theme';
import { commonStyles } from '@/constants/styles';
import { PlanCard } from '@/components';
import { useUser } from '@/hooks/useUser';
import { planService } from '@/services/planService';
import { PlanType } from '@/types';

export default function PlansScreen() {
  const insets = useSafeAreaInsets();
  const { user, updatePlan } = useUser();
  const plans = planService.getAllPlans();

  const handleSelectPlan = (planType: PlanType) => {
    if (planType === user.plan) return;

    if (planType === 'free') {
      Alert.alert(
        'Cancelar Assinatura',
        'Tem certeza que deseja voltar para o plano gratuito? Você perderá acesso aos recursos premium.',
        [
          { text: 'Não', style: 'cancel' },
          { 
            text: 'Sim, cancelar', 
            style: 'destructive',
            onPress: () => {
              updatePlan('free');
              Alert.alert('Sucesso', 'Você voltou para o plano gratuito.');
            }
          },
        ]
      );
    } else {
      Alert.alert(
        'Assinar Plano',
        `Deseja assinar o plano ${planType === 'premium' ? 'Premium' : 'Profissional'}?`,
        [
          { text: 'Cancelar', style: 'cancel' },
          { 
            text: 'Confirmar', 
            onPress: () => {
              // Here you would integrate with payment service
              updatePlan(planType);
              Alert.alert(
                'Sucesso! 🎉',
                `Bem-vindo ao plano ${planType === 'premium' ? 'Premium' : 'Profissional'}! Agora você tem acesso completo a todos os recursos.`
              );
            }
          },
        ]
      );
    }
  };

  return (
    <View style={[commonStyles.container, { paddingTop: insets.top }]}>
      <ScrollView 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Escolha seu Plano</Text>
          <Text style={styles.subtitle}>
            Selecione o plano ideal para ajudar no desenvolvimento do seu filho
          </Text>
        </View>

        {/* Current Plan Info */}
        <View style={styles.currentPlanInfo}>
          <Text style={styles.currentPlanLabel}>Seu plano atual:</Text>
          <Text style={styles.currentPlanName}>
            {user.plan === 'free' ? 'Gratuito' : user.plan === 'premium' ? 'Premium' : 'Profissional'}
          </Text>
        </View>

        {/* Plans */}
        {plans.map((plan) => (
          <PlanCard
            key={plan.type}
            plan={plan}
            isCurrentPlan={user.plan === plan.type}
            onSelect={() => handleSelectPlan(plan.type)}
          />
        ))}

        {/* Footer Info */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>
            ✓ Cancele a qualquer momento{'\n'}
            ✓ Suporte especializado{'\n'}
            ✓ Atualizações constantes de conteúdo
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  content: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.xxl,
  },
  header: {
    paddingTop: spacing.lg,
    paddingBottom: spacing.lg,
    alignItems: 'center',
  },
  title: {
    ...typography.h1,
    fontSize: 28,
    color: colors.text,
    marginBottom: spacing.sm,
    textAlign: 'center',
  },
  subtitle: {
    ...typography.body,
    color: colors.textSecondary,
    textAlign: 'center',
    paddingHorizontal: spacing.md,
  },
  currentPlanInfo: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: spacing.md,
    marginBottom: spacing.lg,
    alignItems: 'center',
  },
  currentPlanLabel: {
    ...typography.bodySmall,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
  currentPlanName: {
    ...typography.h3,
    color: colors.primary,
  },
  footer: {
    marginTop: spacing.lg,
    padding: spacing.lg,
    backgroundColor: colors.surfaceVariant,
    borderRadius: 12,
  },
  footerText: {
    ...typography.body,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 24,
  },
});
