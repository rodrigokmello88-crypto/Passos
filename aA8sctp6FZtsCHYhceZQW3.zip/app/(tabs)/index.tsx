import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, borderRadius, typography, shadows } from '@/constants/theme';
import { commonStyles } from '@/constants/styles';
import { CategoryCard, UpgradeModal, Logo } from '@/components';
import { useUser } from '@/hooks/useUser';
import { resourceService } from '@/services/resourceService';
import { ResourceCategory } from '@/types';
import { useRouter } from 'expo-router';

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const { user } = useUser();
  const router = useRouter();
  const [upgradeModalVisible, setUpgradeModalVisible] = useState(false);

  const categories: Array<{
    category: ResourceCategory;
    title: string;
    icon: keyof typeof Ionicons.glyphMap;
    color: string;
  }> = [
    { category: 'diet', title: 'Alimentação', icon: 'restaurant', color: colors.diet },
    { category: 'therapy', title: 'Terapias', icon: 'fitness', color: colors.therapy },
    { category: 'motor', title: 'Coordenação Motora', icon: 'body', color: colors.motor },
    { category: 'communication', title: 'Comunicação', icon: 'chatbubbles', color: colors.communication },
    { category: 'sensory', title: 'Integração Sensorial', icon: 'hand-left', color: colors.sensory },
    { category: 'behavior', title: 'Comportamento', icon: 'happy', color: colors.behavior },
  ];

  const getCategoryCount = (category: ResourceCategory) => {
    return resourceService.getResourcesByCategory(category).length;
  };

  return (
    <View style={[commonStyles.container, { paddingTop: insets.top }]}>
      <ScrollView 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: spacing.xxl }}
      >
        {/* Logo */}
        <View style={styles.logoContainer}>
          <Logo size={80} />
          <Text style={styles.appName}>Passos</Text>
          <Text style={styles.appTagline}>Cada passo importa no desenvolvimento</Text>
        </View>

        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Olá, {user.name} 👋</Text>
            <Text style={styles.subtitle}>Como podemos ajudar hoje?</Text>
          </View>
          <TouchableOpacity 
            style={styles.planBadge}
            onPress={() => router.push('/plans')}
            activeOpacity={0.7}
          >
            <Ionicons 
              name={user.plan === 'free' ? 'lock-closed' : 'star'} 
              size={16} 
              color={user.plan === 'free' ? colors.textSecondary : colors.premium} 
            />
            <Text style={[
              styles.planText,
              user.plan !== 'free' && styles.premiumPlanText
            ]}>
              {user.plan === 'free' ? 'Gratuito' : user.plan === 'premium' ? 'Premium' : 'Pro'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Stats Cards */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Ionicons name="book" size={28} color={colors.primary} />
            <Text style={styles.statNumber}>
              {user.plan === 'free' ? '18' : resourceService.getAllResources().length}
            </Text>
            <Text style={styles.statLabel}>Recursos</Text>
          </View>
          <View style={styles.statCard}>
            <Ionicons name="grid" size={28} color={colors.secondary} />
            <Text style={styles.statNumber}>6</Text>
            <Text style={styles.statLabel}>Categorias</Text>
          </View>
          <View style={styles.statCard}>
            <Ionicons name="time" size={28} color={colors.accent} />
            <Text style={styles.statNumber}>24/7</Text>
            <Text style={styles.statLabel}>Disponível</Text>
          </View>
        </View>

        {/* Premium Banner */}
        {user.plan === 'free' && (
          <TouchableOpacity 
            style={styles.premiumBanner}
            onPress={() => setUpgradeModalVisible(true)}
            activeOpacity={0.8}
          >
            <View style={styles.premiumContent}>
              <View style={styles.premiumIcon}>
                <Ionicons name="star" size={24} color={colors.premium} />
              </View>
              <View style={styles.premiumText}>
                <Text style={styles.premiumTitle}>Desbloqueie Todo o Conteúdo</Text>
                <Text style={styles.premiumSubtitle}>Acesse recursos premium por R$ 29,90/mês</Text>
              </View>
              <Ionicons name="chevron-forward" size={24} color={colors.primary} />
            </View>
          </TouchableOpacity>
        )}

        {/* Categories */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Explore por Categoria</Text>
          {categories.map((cat) => (
            <CategoryCard
              key={cat.category}
              category={cat.category}
              title={cat.title}
              icon={cat.icon}
              color={cat.color}
              count={getCategoryCount(cat.category)}
              onPress={() => router.push('/library')}
            />
          ))}
        </View>
      </ScrollView>

      <UpgradeModal
        visible={upgradeModalVisible}
        onClose={() => setUpgradeModalVisible(false)}
        onUpgrade={() => {
          setUpgradeModalVisible(false);
          router.push('/plans');
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  logoContainer: {
    alignItems: 'center',
    paddingTop: spacing.lg,
    paddingBottom: spacing.md,
  },
  appName: {
    ...typography.h1,
    fontSize: 32,
    color: colors.primary,
    marginTop: spacing.md,
    fontWeight: '700',
  },
  appTagline: {
    ...typography.bodySmall,
    color: colors.textSecondary,
    marginTop: spacing.xs,
    fontStyle: 'italic',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: spacing.lg,
  },
  greeting: {
    ...typography.h1,
    fontSize: 28,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  subtitle: {
    ...typography.body,
    color: colors.textSecondary,
  },
  planBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.full,
    ...shadows.sm,
    gap: spacing.xs,
  },
  planText: {
    ...typography.bodySmall,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  premiumPlanText: {
    color: colors.premium,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.lg,
    gap: spacing.md,
  },
  statCard: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    alignItems: 'center',
    ...shadows.md,
  },
  statNumber: {
    ...typography.h2,
    fontSize: 22,
    color: colors.text,
    marginTop: spacing.sm,
    marginBottom: spacing.xs,
  },
  statLabel: {
    ...typography.caption,
    color: colors.textSecondary,
  },
  premiumBanner: {
    marginHorizontal: spacing.lg,
    marginBottom: spacing.lg,
    backgroundColor: colors.primary,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    ...shadows.lg,
  },
  premiumContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  premiumIcon: {
    width: 48,
    height: 48,
    borderRadius: borderRadius.md,
    backgroundColor: colors.surface,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  premiumText: {
    flex: 1,
  },
  premiumTitle: {
    ...typography.h3,
    fontSize: 16,
    color: colors.surface,
    marginBottom: spacing.xs,
  },
  premiumSubtitle: {
    ...typography.bodySmall,
    color: colors.surface,
    opacity: 0.9,
  },
  section: {
    paddingHorizontal: spacing.lg,
  },
  sectionTitle: {
    ...typography.h2,
    fontSize: 22,
    color: colors.text,
    marginBottom: spacing.md,
  },
});
