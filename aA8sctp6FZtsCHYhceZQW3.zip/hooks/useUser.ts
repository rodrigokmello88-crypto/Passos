import { useState } from 'react';
import { User, PlanType } from '@/types';

export function useUser() {
  const [user, setUser] = useState<User>({
    id: '1',
    name: 'Usuário',
    email: 'usuario@example.com',
    plan: 'free',
  });

  const updatePlan = (plan: PlanType) => {
    setUser(prev => ({ ...prev, plan }));
  };

  return {
    user,
    updatePlan,
  };
}
