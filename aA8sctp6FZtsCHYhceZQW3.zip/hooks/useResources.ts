import { useState, useMemo } from 'react';
import { Resource, ResourceCategory, PlanType } from '@/types';
import { resourceService } from '@/services/resourceService';
import { planService } from '@/services/planService';

export function useResources(userPlan: PlanType) {
  const [selectedCategory, setSelectedCategory] = useState<ResourceCategory | 'all'>('all');

  const allResources = useMemo(() => resourceService.getAllResources(), []);

  const filteredResources = useMemo(() => {
    if (selectedCategory === 'all') return allResources;
    return resourceService.getResourcesByCategory(selectedCategory);
  }, [selectedCategory, allResources]);

  const canAccess = (resource: Resource): boolean => {
    return planService.canAccessResource(userPlan, resource.isPremium);
  };

  return {
    resources: filteredResources,
    selectedCategory,
    setSelectedCategory,
    canAccess,
  };
}
