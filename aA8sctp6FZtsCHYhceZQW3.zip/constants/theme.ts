export const colors = {
  // Primary Colors
  primary: '#4A90E2',
  primaryDark: '#357ABD',
  primaryLight: '#7FB3E8',
  
  // Secondary Colors
  secondary: '#50C878',
  secondaryDark: '#3DA860',
  secondaryLight: '#7ED99A',
  
  // Accent Colors
  accent: '#FFB74D',
  accentDark: '#F57C00',
  warning: '#FF9800',
  
  // Background Colors
  background: '#F8F9FA',
  surface: '#FFFFFF',
  surfaceVariant: '#F5F7FA',
  
  // Text Colors
  text: '#2C3E50',
  textSecondary: '#7F8C8D',
  textLight: '#95A5A6',
  
  // Status Colors
  success: '#27AE60',
  error: '#E74C3C',
  info: '#3498DB',
  
  // Border & Divider
  border: '#E1E8ED',
  divider: '#ECF0F1',
  
  // Premium Colors
  premium: '#FFD700',
  premiumDark: '#FFA000',
  
  // Category Colors
  diet: '#FF7675',
  therapy: '#74B9FF',
  motor: '#55EFC4',
  communication: '#A29BFE',
  sensory: '#FDCB6E',
  behavior: '#FF9FF3',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 40,
};

export const typography = {
  h1: {
    fontSize: 32,
    fontWeight: '700' as const,
    lineHeight: 40,
  },
  h2: {
    fontSize: 24,
    fontWeight: '600' as const,
    lineHeight: 32,
  },
  h3: {
    fontSize: 20,
    fontWeight: '600' as const,
    lineHeight: 28,
  },
  body: {
    fontSize: 16,
    fontWeight: '400' as const,
    lineHeight: 24,
  },
  bodySmall: {
    fontSize: 14,
    fontWeight: '400' as const,
    lineHeight: 20,
  },
  caption: {
    fontSize: 12,
    fontWeight: '400' as const,
    lineHeight: 16,
  },
  button: {
    fontSize: 16,
    fontWeight: '600' as const,
    lineHeight: 24,
  },
};

export const borderRadius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 9999,
};

export const shadows = {
  sm: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 3,
  },
  lg: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 5,
  },
};
