import { Resource, ResourceCategory } from '@/types';

export const resourceService = {
  getAllResources: (): Resource[] => {
    return mockResources;
  },

  getResourcesByCategory: (category: ResourceCategory): Resource[] => {
    return mockResources.filter(resource => resource.category === category);
  },

  getResourceById: (id: string): Resource | undefined => {
    return mockResources.find(resource => resource.id === id);
  },

  getFreeResources: (): Resource[] => {
    return mockResources.filter(resource => !resource.isPremium);
  },

  getPremiumResources: (): Resource[] => {
    return mockResources.filter(resource => resource.isPremium);
  },
};

const mockResources: Resource[] = [
  {
    id: '1',
    title: 'Dieta Sem Glúten e Caseína',
    description: 'Guia completo sobre alimentação GFCF e seus benefícios para crianças autistas',
    category: 'diet',
    isPremium: false,
    content: 'A dieta sem glúten e caseína pode ajudar a reduzir sintomas em algumas crianças autistas...',
    duration: '10 min',
    difficulty: 'medium',
    tags: ['alimentação', 'dieta', 'saúde'],
  },
  {
    id: '2',
    title: 'Alimentos Ricos em Ômega-3',
    description: 'Lista de alimentos essenciais para o desenvolvimento cerebral',
    category: 'diet',
    isPremium: true,
    content: 'Ômega-3 é fundamental para o desenvolvimento neurológico...',
    duration: '8 min',
    difficulty: 'easy',
    tags: ['nutrição', 'suplementos'],
  },
  {
    id: '3',
    title: 'Exercícios de Fisioterapia em Casa',
    description: 'Rotina diária de exercícios para desenvolvimento motor',
    category: 'therapy',
    isPremium: false,
    content: 'Exercícios simples que podem ser feitos em casa...',
    duration: '15 min',
    difficulty: 'easy',
    tags: ['fisioterapia', 'exercícios'],
  },
  {
    id: '4',
    title: 'Terapia ABA - Técnicas Básicas',
    description: 'Introdução às técnicas de Análise do Comportamento Aplicada',
    category: 'behavior',
    isPremium: true,
    content: 'ABA é uma abordagem científica baseada em evidências...',
    duration: '20 min',
    difficulty: 'medium',
    tags: ['aba', 'comportamento', 'terapia'],
  },
  {
    id: '5',
    title: 'Desenvolvimento da Coordenação Motora',
    description: 'Atividades lúdicas para melhorar coordenação fina e grossa',
    category: 'motor',
    isPremium: false,
    content: 'Atividades práticas para desenvolvimento motor...',
    duration: '12 min',
    difficulty: 'easy',
    tags: ['coordenação', 'motricidade'],
  },
  {
    id: '6',
    title: 'Comunicação Alternativa (PECS)',
    description: 'Sistema de comunicação por troca de figuras',
    category: 'communication',
    isPremium: true,
    content: 'PECS é um sistema de comunicação alternativa...',
    duration: '18 min',
    difficulty: 'medium',
    tags: ['pecs', 'comunicação', 'fala'],
  },
  {
    id: '7',
    title: 'Integração Sensorial em Casa',
    description: 'Atividades para estimulação sensorial no ambiente doméstico',
    category: 'sensory',
    isPremium: false,
    content: 'Técnicas de integração sensorial adaptadas para casa...',
    duration: '15 min',
    difficulty: 'easy',
    tags: ['sensorial', 'estimulação'],
  },
  {
    id: '8',
    title: 'Gestão de Crises e Comportamentos',
    description: 'Estratégias para lidar com momentos de crise',
    category: 'behavior',
    isPremium: true,
    content: 'Como identificar gatilhos e prevenir crises...',
    duration: '25 min',
    difficulty: 'hard',
    tags: ['crise', 'comportamento', 'emergência'],
  },
  {
    id: '9',
    title: 'Cardápio Semanal Balanceado',
    description: 'Planejamento de refeições nutritivas e sensorialmente adequadas',
    category: 'diet',
    isPremium: true,
    content: 'Plano alimentar completo para a semana...',
    duration: '10 min',
    difficulty: 'medium',
    tags: ['cardápio', 'planejamento', 'nutrição'],
  },
  {
    id: '10',
    title: 'Massagem Terapêutica',
    description: 'Técnicas de massagem para relaxamento e conexão',
    category: 'therapy',
    isPremium: true,
    content: 'Massagens adaptadas para crianças autistas...',
    duration: '12 min',
    difficulty: 'easy',
    tags: ['massagem', 'relaxamento', 'toque'],
  },
];
