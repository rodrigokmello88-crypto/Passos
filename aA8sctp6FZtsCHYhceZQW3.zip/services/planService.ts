import { Plan, PlanType } from '@/types';

export const planService = {
  getAllPlans: (): Plan[] => {
    return plans;
  },

  getPlanByType: (type: PlanType): Plan | undefined => {
    return plans.find(plan => plan.type === type);
  },

  canAccessResource: (userPlan: PlanType, resourceIsPremium: boolean): boolean => {
    if (!resourceIsPremium) return true;
    return userPlan === 'premium' || userPlan === 'pro';
  },
};

const plans: Plan[] = [
  {
    type: 'free',
    name: 'Gratuito',
    price: 'R$ 0',
    features: [
      'Acesso a recursos básicos',
      'Guias introdutórios',
      '3 recursos de cada categoria',
      'Suporte por email',
    ],
  },
  {
    type: 'premium',
    name: 'Premium',
    price: 'R$ 29,90/mês',
    popular: true,
    features: [
      'Acesso completo a todos os recursos',
      'Guias avançados e especializados',
      'Planos alimentares personalizados',
      'Vídeos demonstrativos',
      'Suporte prioritário',
      'Atualizações mensais',
    ],
  },
  {
    type: 'pro',
    name: 'Profissional',
    price: 'R$ 49,90/mês',
    features: [
      'Tudo do plano Premium',
      'Consultoria mensal com especialistas',
      'Planos terapêuticos personalizados',
      'Acompanhamento de progresso',
      'Comunidade exclusiva de pais',
      'Materiais para impressão',
      'Suporte 24/7',
    ],
  },
];
