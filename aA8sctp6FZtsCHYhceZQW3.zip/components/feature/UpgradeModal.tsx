import React from 'react';
import { View, Text, StyleSheet, Modal, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, borderRadius, typography, shadows } from '@/constants/theme';

interface UpgradeModalProps {
  visible: boolean;
  onClose: () => void;
  onUpgrade: () => void;
}

export function UpgradeModal({ visible, onClose, onUpgrade }: UpgradeModalProps) {
  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <View style={styles.modal}>
          <TouchableOpacity style={styles.closeButton} onPress={onClose}>
            <Ionicons name="close" size={28} color={colors.text} />
          </TouchableOpacity>
          
          <ScrollView showsVerticalScrollIndicator={false}>
            <View style={styles.header}>
              <View style={styles.iconContainer}>
                <Ionicons name="lock-closed" size={40} color={colors.premium} />
              </View>
              <Text style={styles.title}>Conteúdo Premium</Text>
              <Text style={styles.subtitle}>
                Desbloqueie acesso completo a todos os recursos e técnicas especializadas
              </Text>
            </View>
            
            <View style={styles.benefits}>
              {benefits.map((benefit, index) => (
                <View key={index} style={styles.benefit}>
                  <Ionicons name={benefit.icon} size={24} color={colors.primary} />
                  <View style={styles.benefitText}>
                    <Text style={styles.benefitTitle}>{benefit.title}</Text>
                    <Text style={styles.benefitDescription}>{benefit.description}</Text>
                  </View>
                </View>
              ))}
            </View>
            
            <TouchableOpacity style={styles.upgradeButton} onPress={onUpgrade} activeOpacity={0.8}>
              <Text style={styles.upgradeButtonText}>Assinar Agora</Text>
              <Text style={styles.upgradeButtonSubtext}>A partir de R$ 29,90/mês</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.cancelButton} onPress={onClose}>
              <Text style={styles.cancelButtonText}>Continuar com Plano Gratuito</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const benefits = [
  {
    icon: 'book' as const,
    title: 'Guias Completos',
    description: 'Acesso a todos os guias e técnicas avançadas',
  },
  {
    icon: 'restaurant' as const,
    title: 'Planos Alimentares',
    description: 'Cardápios personalizados e receitas especializadas',
  },
  {
    icon: 'fitness' as const,
    title: 'Exercícios Detalhados',
    description: 'Vídeos e instruções passo a passo',
  },
  {
    icon: 'headset' as const,
    title: 'Suporte Prioritário',
    description: 'Tire suas dúvidas com especialistas',
  },
];

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modal: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: borderRadius.xl,
    borderTopRightRadius: borderRadius.xl,
    paddingTop: spacing.xl,
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.xxl,
    maxHeight: '90%',
    ...shadows.lg,
  },
  closeButton: {
    position: 'absolute',
    top: spacing.md,
    right: spacing.md,
    zIndex: 1,
    padding: spacing.xs,
  },
  header: {
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: borderRadius.full,
    backgroundColor: colors.premium + '20',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  title: {
    ...typography.h1,
    fontSize: 28,
    color: colors.text,
    marginBottom: spacing.sm,
    textAlign: 'center',
  },
  subtitle: {
    ...typography.body,
    color: colors.textSecondary,
    textAlign: 'center',
    paddingHorizontal: spacing.md,
  },
  benefits: {
    marginBottom: spacing.xl,
  },
  benefit: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: spacing.lg,
  },
  benefitText: {
    flex: 1,
    marginLeft: spacing.md,
  },
  benefitTitle: {
    ...typography.h3,
    fontSize: 16,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  benefitDescription: {
    ...typography.bodySmall,
    color: colors.textSecondary,
  },
  upgradeButton: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.md,
    alignItems: 'center',
    marginBottom: spacing.md,
    ...shadows.md,
  },
  upgradeButtonText: {
    ...typography.button,
    fontSize: 18,
    color: colors.surface,
    marginBottom: spacing.xs,
  },
  upgradeButtonSubtext: {
    ...typography.caption,
    color: colors.surface,
    opacity: 0.9,
  },
  cancelButton: {
    paddingVertical: spacing.md,
    alignItems: 'center',
  },
  cancelButtonText: {
    ...typography.body,
    color: colors.textSecondary,
  },
});
