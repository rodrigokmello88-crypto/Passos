import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, borderRadius, typography, shadows } from '@/constants/theme';
import { Resource } from '@/types';
import { Badge } from '@/components/ui/Badge';

interface ResourceCardProps {
  resource: Resource;
  canAccess: boolean;
  onPress: () => void;
}

export function ResourceCard({ resource, canAccess, onPress }: ResourceCardProps) {
  const categoryColors: Record<string, string> = {
    diet: colors.diet,
    therapy: colors.therapy,
    motor: colors.motor,
    communication: colors.communication,
    sensory: colors.sensory,
    behavior: colors.behavior,
  };

  return (
    <TouchableOpacity 
      style={[styles.card, !canAccess && styles.locked]} 
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={styles.header}>
        <View style={styles.badges}>
          {resource.isPremium && <Badge label="Premium" variant="premium" />}
          {resource.duration && (
            <Badge label={resource.duration} variant="secondary" />
          )}
        </View>
        {!canAccess && (
          <Ionicons name="lock-closed" size={20} color={colors.textSecondary} />
        )}
      </View>
      
      <Text style={styles.title} numberOfLines={2}>
        {resource.title}
      </Text>
      
      <Text style={styles.description} numberOfLines={2}>
        {resource.description}
      </Text>
      
      <View style={styles.footer}>
        <View style={styles.tags}>
          {resource.tags.slice(0, 2).map((tag, index) => (
            <View 
              key={index} 
              style={[
                styles.tag, 
                { backgroundColor: categoryColors[resource.category] + '20' }
              ]}
            >
              <Text style={[styles.tagText, { color: categoryColors[resource.category] }]}>
                {tag}
              </Text>
            </View>
          ))}
        </View>
        {resource.difficulty && (
          <Text style={styles.difficulty}>
            {getDifficultyLabel(resource.difficulty)}
          </Text>
        )}
      </View>
    </TouchableOpacity>
  );
}

function getDifficultyLabel(difficulty: string): string {
  const labels = {
    easy: 'Fácil',
    medium: 'Médio',
    hard: 'Avançado',
  };
  return labels[difficulty as keyof typeof labels] || difficulty;
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
    ...shadows.md,
  },
  locked: {
    opacity: 0.6,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  badges: {
    flexDirection: 'row',
    gap: spacing.xs,
  },
  title: {
    ...typography.h3,
    fontSize: 18,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  description: {
    ...typography.body,
    color: colors.textSecondary,
    marginBottom: spacing.md,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  tags: {
    flexDirection: 'row',
    gap: spacing.xs,
    flex: 1,
  },
  tag: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.sm,
  },
  tagText: {
    ...typography.caption,
    fontWeight: '600',
  },
  difficulty: {
    ...typography.caption,
    color: colors.textSecondary,
    fontWeight: '600',
  },
});
