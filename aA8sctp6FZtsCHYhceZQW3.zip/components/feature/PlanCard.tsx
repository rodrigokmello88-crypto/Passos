import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, borderRadius, typography, shadows } from '@/constants/theme';
import { Plan } from '@/types';

interface PlanCardProps {
  plan: Plan;
  isCurrentPlan: boolean;
  onSelect: () => void;
}

export function PlanCard({ plan, isCurrentPlan, onSelect }: PlanCardProps) {
  return (
    <View style={[
      styles.card,
      plan.popular && styles.popularCard,
      isCurrentPlan && styles.currentPlanCard,
    ]}>
      {plan.popular && (
        <View style={styles.popularBadge}>
          <Text style={styles.popularText}>MAIS POPULAR</Text>
        </View>
      )}
      
      <Text style={styles.planName}>{plan.name}</Text>
      <Text style={styles.price}>{plan.price}</Text>
      
      <View style={styles.features}>
        {plan.features.map((feature, index) => (
          <View key={index} style={styles.feature}>
            <Ionicons name="checkmark-circle" size={20} color={colors.success} />
            <Text style={styles.featureText}>{feature}</Text>
          </View>
        ))}
      </View>
      
      <TouchableOpacity 
        style={[
          styles.button,
          isCurrentPlan && styles.currentButton,
          plan.popular && !isCurrentPlan && styles.popularButton,
        ]}
        onPress={onSelect}
        disabled={isCurrentPlan}
        activeOpacity={0.7}
      >
        <Text style={[
          styles.buttonText,
          isCurrentPlan && styles.currentButtonText,
        ]}>
          {isCurrentPlan ? 'Plano Atual' : 'Selecionar'}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    ...shadows.md,
    borderWidth: 2,
    borderColor: colors.border,
  },
  popularCard: {
    borderColor: colors.primary,
    ...shadows.lg,
  },
  currentPlanCard: {
    borderColor: colors.success,
    backgroundColor: colors.success + '08',
  },
  popularBadge: {
    backgroundColor: colors.primary,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.sm,
    alignSelf: 'flex-start',
    marginBottom: spacing.md,
  },
  popularText: {
    ...typography.caption,
    color: colors.surface,
    fontWeight: '700',
  },
  planName: {
    ...typography.h2,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  price: {
    ...typography.h3,
    fontSize: 22,
    color: colors.primary,
    marginBottom: spacing.lg,
  },
  features: {
    marginBottom: spacing.lg,
  },
  feature: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  featureText: {
    ...typography.body,
    color: colors.text,
    marginLeft: spacing.sm,
    flex: 1,
  },
  button: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.md,
    alignItems: 'center',
  },
  popularButton: {
    backgroundColor: colors.primaryDark,
  },
  currentButton: {
    backgroundColor: colors.border,
  },
  buttonText: {
    ...typography.button,
    color: colors.surface,
  },
  currentButtonText: {
    color: colors.textSecondary,
  },
});
