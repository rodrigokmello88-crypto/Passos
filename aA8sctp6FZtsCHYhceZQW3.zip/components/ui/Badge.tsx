import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, spacing, borderRadius, typography } from '@/constants/theme';

interface BadgeProps {
  label: string;
  variant?: 'primary' | 'secondary' | 'premium' | 'success';
}

export function Badge({ label, variant = 'primary' }: BadgeProps) {
  return (
    <View style={[styles.badge, styles[variant]]}>
      <Text style={[styles.text, styles[`${variant}Text`]]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.sm,
    alignSelf: 'flex-start',
  },
  text: {
    ...typography.caption,
    fontWeight: '600',
  },
  primary: {
    backgroundColor: colors.primaryLight,
  },
  primaryText: {
    color: colors.primaryDark,
  },
  secondary: {
    backgroundColor: colors.secondaryLight,
  },
  secondaryText: {
    color: colors.secondaryDark,
  },
  premium: {
    backgroundColor: colors.premium,
  },
  premiumText: {
    color: colors.accentDark,
  },
  success: {
    backgroundColor: colors.success,
  },
  successText: {
    color: colors.surface,
  },
});
