import React from 'react';
import { View, StyleSheet } from 'react-native';
import { colors } from '@/constants/theme';

interface LogoProps {
  size?: number;
}

export function Logo({ size = 120 }: LogoProps) {
  const scale = size / 120;
  
  return (
    <View style={[styles.container, { width: size, height: size }]}>
      {/* Heart shape background */}
      <View style={[styles.heartContainer, { transform: [{ scale }] }]}>
        <View style={styles.heartLeft} />
        <View style={styles.heartRight} />
        <View style={styles.heartBottom} />
      </View>
      
      {/* Footsteps inside heart */}
      <View style={[styles.footstepsContainer, { transform: [{ scale: scale * 0.6 }] }]}>
        {/* Left footstep - smaller, lighter */}
        <View style={[styles.footstep, styles.leftFoot]}>
          <View style={[styles.heel, { backgroundColor: colors.primaryLight }]} />
          <View style={styles.toes}>
            <View style={[styles.toe, { backgroundColor: colors.primaryLight }]} />
            <View style={[styles.toe, { backgroundColor: colors.primaryLight }]} />
            <View style={[styles.toe, { backgroundColor: colors.primaryLight }]} />
          </View>
        </View>
        
        {/* Right footstep - bigger, darker */}
        <View style={[styles.footstep, styles.rightFoot]}>
          <View style={[styles.heel, styles.heelLarge, { backgroundColor: colors.primary }]} />
          <View style={styles.toes}>
            <View style={[styles.toe, styles.toeLarge, { backgroundColor: colors.primary }]} />
            <View style={[styles.toe, styles.toeLarge, { backgroundColor: colors.primary }]} />
            <View style={[styles.toe, styles.toeLarge, { backgroundColor: colors.primary }]} />
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  heartContainer: {
    width: 100,
    height: 90,
    position: 'absolute',
  },
  heartLeft: {
    position: 'absolute',
    top: 0,
    left: 20,
    width: 30,
    height: 48,
    backgroundColor: colors.secondary,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    transform: [{ rotate: '-45deg' }],
  },
  heartRight: {
    position: 'absolute',
    top: 0,
    right: 20,
    width: 30,
    height: 48,
    backgroundColor: colors.secondary,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    transform: [{ rotate: '45deg' }],
  },
  heartBottom: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 50,
    backgroundColor: colors.secondary,
    borderBottomLeftRadius: 50,
    borderBottomRightRadius: 50,
    transform: [{ rotate: '45deg' }],
  },
  footstepsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  footstep: {
    alignItems: 'center',
  },
  leftFoot: {
    marginTop: -10,
  },
  rightFoot: {
    marginTop: 10,
  },
  heel: {
    width: 16,
    height: 22,
    borderRadius: 12,
    marginBottom: 3,
  },
  heelLarge: {
    width: 20,
    height: 28,
    borderRadius: 14,
  },
  toes: {
    flexDirection: 'row',
    gap: 2,
  },
  toe: {
    width: 4,
    height: 6,
    borderRadius: 3,
  },
  toeLarge: {
    width: 5,
    height: 8,
    borderRadius: 4,
  },
});
